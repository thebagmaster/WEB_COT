<?php

$con = mysql_connect("localhost","root","");
if(!mysql_select_db("futures", $con))
{
	mysql_query("CREATE DATABASE futures",$con);
	mysql_select_db("futures", $con);
	mysql_select_db("my_db", $con);
	mysql_query("CREATE TABLE dx
(
date DATE,
open FLOAT,
high FLOAT,
low FLOAT,
close FLOAT,
volume INT,
interest INT
)",$con);
};

?>